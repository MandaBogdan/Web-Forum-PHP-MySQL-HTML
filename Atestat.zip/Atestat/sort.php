<?php
///sortare
@session_start();
error_reporting(E_ALL & ~E_DEPRECATED);
$msql=mysql_connect("localhost","root","");
$baza=mysql_select_db("site");
$rezultat=mysql_query("SELECT * FROM text order by id DESC");
if($_POST['S']=='unu')
	$rezultat=mysql_query("SELECT * FROM text order by likes desc");
else
if($_POST['S']=='doi')
	$rezultat=mysql_query("SELECT * FROM text order by dislike desc");
else
if($_POST['S']=='trei')
$rezultat=mysql_query("SELECT * FROM text ");

if(!$rezultat)
	echo mysql_error();

$_SESSION['mod']=$rezultat;
require_once('afisare.php');

?>