<?php
error_reporting(E_ALL & ~E_DEPRECATED);
@session_start();
mysql_connect("localhost","root","");
mysql_select_db('site');

$idn=$_POST['IDL'];
$like=$_POST['lik'];
$dislike=$_POST['dis'];
if($_POST['L']==1)
	$like=$like+1;
else
	$dislike=$dislike+1;

$baza=mysql_query("update text set likes='$like', dislike='$dislike' where id='$idn' ");
$_SESSION['mod']=mysql_query("SELECT * FROM text order by id DESC");
require_once("afisare.php");
?>