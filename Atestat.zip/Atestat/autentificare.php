<?php
require_once('banner.php');
error_reporting(E_ALL & ~E_DEPRECATED);
@session_start();
$msql=mysql_connect("localhost","root","");
if(!$msql)
{echo "Nu s-a realizat conectarea la MySQL "; exit;}

$baza=mysql_select_db("site");

$numea=$_POST['nume'];
$maila=$_POST['mail'];
$pasa=$_POST['pas1'];

$cerere="SELECT nume FROM vizitatori WHERE mail='$maila' AND pass='$pasa'";
$rezultat=mysql_query($cerere);
$rand=mysql_fetch_array($rezultat);

if ($rand["nume"]!=$numea)
{
echo '<font face=myFirstFont color=#f2f2f2 size=9><div class=center>';
echo "Conectare esuata.".'</font></div>';	
}
else 
{
	$_SESSION['user']=$rand["nume"];
	$rezultat=mysql_query("SELECT * FROM text order by id DESC");
	$_SESSION['mod']=$rezultat;
	require_once("afisare.php"); 
}
?>