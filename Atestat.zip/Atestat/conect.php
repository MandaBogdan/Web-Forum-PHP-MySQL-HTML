<?php
error_reporting(E_ALL & ~E_DEPRECATED);
$msql=mysql_connect("localhost","root","");
if(!$msql)
{echo "Nu s-a realizat conectarea la MySQL "; exit;}

$ok=mysql_query("create database site");

$baza=mysql_select_db("site");

if (!$baza)
{echo mysql_errno().":".mysql_error(); exit;}

mysql_query("CREATE TABLE vizitatori(nume char(200), mail CHAR(200), pass char(200))");
mysql_query("CREATE TABLE text(id mediumint not NULL auto_increment ,coment char(200), likes int(30), dislike int(30), username char(200), primary key(id))");
?>