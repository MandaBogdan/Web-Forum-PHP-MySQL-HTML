<?php
error_reporting(E_ALL & ~E_DEPRECATED);
require_once('banner.php');
require_once('conect.php');
echo"
<html>
<head>
<link rel='stylesheet' type='text/css' href='style.css'>
</head>

<font face=myFirstFont color=#f2f2f2>
<font size=9>CINE SUNTEM?</font><BR>
<div class=quotes>
<font size=5>
BOPINNI este un website in care orice persoana este incurajata sa isi exprime idei, opinii in legatura cu variate 
teme.</div></font>
<BR><BR>

<font size=9>DE CE?</font><BR>
<font size=5>
<div class=quotes>
	Vi s-a intamplat vreodata sa trebuiasca sa dezvoltati un concept, de exemplu un atestat la informatica, si sa va 
gasiti in imposibilitatea de decide intre toate ideile creative pe care le aveti? Ei bine, BOPINNI este site-ul
in care va puteti exprima aceste idei, lasand alte persoane sa isi exprime opinia asupra acestor idei.<BR>
Astfel, deciziile vor deveni mai clare, iar timpul de dezvoltare al produsului creativ va deveni considerabil
mai mic!</div></font>
<BR><BR>

<font size=9>CUI II TREBUIE ASA CEVA?</font><BR>
<font size=5>
<div class=quotes>
Ceea ce ofera BOPINNI este perfect pentru persoanele care vor sa ofere un produs pe placul clientilor, deoarece
ofera posibilitatea unei relatii stranse cu creatorul si starea produsului.<BR>
De exemplu un dezvoltator de jocuri care vrea sa se asigure ca viitorul sau joc va fi pe placul jucatorilor
poate cere idei acestora cu privire la diverse aspecte. Folosind functia de like/dislike clientii isi pot exprima
opinia asupra ideilor care sunt sau nu sunt bune. Prin sortarea acestor pareri dupa diferite criterii atent 
implementate in structura siteului, dezvoltatorul va putea face alegerea inteleapta, iar jocul sau va vinde
milioane. ($ v $)</div>
</font>
</font>
"
?>